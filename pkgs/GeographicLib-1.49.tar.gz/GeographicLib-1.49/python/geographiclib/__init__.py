"""geographiclib: geodesic routines from GeographicLib"""

__version_info__ = (1, 49, 0)
"""GeographicLib version as a tuple"""

__version__ = "1.49"
"""GeographicLib version as a string"""
